package com.springsecurity.service;

import java.util.List;

import com.springsecurity.dto.BalanceDetailsDto;
import com.springsecurity.model.Balance_Details;
import com.springsecurity.model.Customer;

public interface BalanceDetailsService {
	public Balance_Details saveBlance(BalanceDetailsDto blanceDetailsDto,Customer customer);
	public List<Balance_Details> getBlanceDetails(Customer customer);
}
