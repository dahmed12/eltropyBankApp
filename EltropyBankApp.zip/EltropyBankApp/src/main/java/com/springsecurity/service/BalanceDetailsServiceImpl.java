package com.springsecurity.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springsecurity.dto.BalanceDetailsDto;
import com.springsecurity.model.Balance_Details;
import com.springsecurity.model.Customer;
import com.springsecurity.repository.BalanceDetailsRepository;
import com.springsecurity.repository.CustomerRepository;

@Service
public class BalanceDetailsServiceImpl implements BalanceDetailsService {

	private final BalanceDetailsRepository blanceDetailsRepository;
	private final CustomerRepository customerRepository;
	private final CustomerService customerService;

	@Autowired
	public BalanceDetailsServiceImpl(BalanceDetailsRepository blanceDetailsRepository, CustomerService customerService,
			CustomerRepository customerRepository) {
		this.blanceDetailsRepository = blanceDetailsRepository;
		this.customerService = customerService;
		this.customerRepository = customerRepository;
	}

	@Override
	public Balance_Details saveBlance(BalanceDetailsDto blanceDetailsDto, Customer customer) {
		if (customer == null) {
			return null;
		}
		List<Balance_Details> blanceDetails = getBlanceDetails(customer);
		int size = blanceDetails.size();
		System.out.println(size);
		Balance_Details blanceDetail=null;
		if (size != 0) {
			 blanceDetail = blanceDetails.get(size - 1);
		} else {
			blanceDetailsRepository.save(new Balance_Details(0l, "", "", customer));
			blanceDetail = blanceDetails.get(size-1);
		}
		if (blanceDetailsDto.getDebit().equalsIgnoreCase("debit")) {
			blanceDetailsDto.setCredit("");
			blanceDetailsDto.setDebit("debit");
			blanceDetailsDto.setBalance(-blanceDetailsDto.getBalance() + blanceDetail.getBlance());
		} else if (blanceDetailsDto.getDebit().equalsIgnoreCase("credit")) {
			blanceDetailsDto.setCredit("credit");
			blanceDetailsDto.setDebit("");
			blanceDetailsDto.setBalance(blanceDetailsDto.getBalance() + blanceDetail.getBlance());
		} else
			return null;
		return blanceDetailsRepository.save(new Balance_Details(blanceDetailsDto.getBalance(),
				blanceDetailsDto.getCredit(), blanceDetailsDto.getDebit(), customer));
	}

	@Override
	public List<Balance_Details> getBlanceDetails(Customer customer) {
		return blanceDetailsRepository.findByForainKey(customer.getId());
	}
}
