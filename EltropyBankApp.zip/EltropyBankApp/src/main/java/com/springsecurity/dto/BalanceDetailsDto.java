package com.springsecurity.dto;

public class BalanceDetailsDto {

	private Long balance;
	private String credit;
	private String debit;

	
	public BalanceDetailsDto() {
	}

	public BalanceDetailsDto(Long blance, String credit, String debit) {
		this.balance = blance;
		this.credit = credit;
		this.debit = debit;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit = debit;
	}

	public BalanceDetailsDto(Long blance) {
		this.balance = blance;
	}

	public Long getBalance() {
		return balance;
	}

	public void setBalance(Long blance) {
		this.balance = blance;
	}

	@Override
	public String toString() {
		return "BalanceDetailsDto [blance=" + balance + "]";
	}
	
}
